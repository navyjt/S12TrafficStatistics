package cal;


import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.LineNumberReader;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JDialog;
import javax.swing.JPanel;


@SuppressWarnings("serial")
public class ReadFileDiag extends JDialog{
	
	private JFrame f = new JFrame("��ȡ�ļ�");
	private JButton importBtn = new JButton("����");
	private JPanel top = new JPanel();
	
	
	static String line;
	static int lineToSkip;
	static FileReader fr;
	static LineNumberReader lnr;
	static String trafficDate;
	static int beginTimeInt;
	static int endTimeInt;
	static String[] traffic1;
	static String[] traffic2;
	
	public ReadFileDiag(JFrame f, String string, boolean b) throws IOException {
		// TODO �Զ����ɵĹ��캯�����
		init();
	}


	public void init() 
	{
		f.setSize(600, 500);
		f.setVisible(true);
		f.setLocationRelativeTo(null);
		top.add(importBtn);
		//execbtn.addActionListener(new ActionListener());
		f.add(top , BorderLayout.NORTH);

	
	importBtn.addActionListener(new ActionListener()
	{

		public void actionPerformed(ActionEvent e) {
			
			try {
				fr = new FileReader("140831A.LOG");
			} catch (FileNotFoundException e1) {
				// TODO �Զ����ɵ� catch ��
				e1.printStackTrace();
			}
			lnr = new LineNumberReader(fr);		
			 line = null;
			String reg = "\\bACTIVATE-TKG-REPORT\\b";
			
			Pattern p = Pattern.compile(reg);

			
			try {
				while ((line = lnr.readLine())!= null)
				{
					Matcher m = p.matcher(line);
					if(m.find())
					{	
						line = lnr.readLine();
						if (line.indexOf("PART 0001")!= -1)
						{
							line = lnr.readLine();
							line = lnr.readLine();
							if(line.indexOf("R E S U L T S") != -1)
							{
								handleTraffic();

							}
							else 
							{
								System.out.println(lnr.getLineNumber()+":"+"�ٵ�Part1�ҵ���");
							}
						}
						if (line.indexOf("PART 0002")!= -1)
						{
							line = lnr.readLine();
							line = lnr.readLine();
							if(line.indexOf("R E S U L T S") != -1)
							{
								handleTraffic();
							}
							else 
							{
								System.out.println(lnr.getLineNumber()+":"+"�ٵ�Part2�ҵ���");
							}
						}
						if (line.indexOf("PART 0003")!= -1)
						{
							line = lnr.readLine();
							line = lnr.readLine();
							if(line.indexOf("R E S U L T S") != -1)
							{
								handleTraffic();

							}
							else 
							{
								System.out.println(lnr.getLineNumber()+":"+"�ٵ�Part3�ҵ���");
							}
						}
						if (line.indexOf("PART 0004")!= -1)
						{
							line = lnr.readLine();
							line = lnr.readLine();
							if(line.indexOf("R E S U L T S") != -1)
							{
								handleTraffic();
							}
							else 
							{
								System.out.println(lnr.getLineNumber()+":"+"�ٵ�Part4�ҵ���");
							}
						}
					}
					
				}
			} catch (IOException e1) {
				// TODO �Զ����ɵ� catch ��
				e1.printStackTrace();
			}
		}
	}
	);
	}
	
	public static void handleTraffic() throws IOException
	{
		skipLine(1);
		getDateFromLine(line);
		skipLine(2);
		getTimeFromLine(line);
		skipLine(8);
		while(line.length() != 0)
		{
			getTrafficFromLine();
			skipLine(1);
		}
	}
	
	//��line���ж�ȡ����
	public static void getDateFromLine(String line)
	{
		String reg = "[0-9]{4}-[A-Z]{3}-[0-9]{2}";
		Pattern p = Pattern.compile(reg);
		Matcher m = p.matcher(line);
		if (m.find())
		{
			trafficDate = m.group();
		//	System.out.println(m.group());
		}
		else
			System.out.println("û�ҵ����ڲ���");
	}
	//��line���ж�ȡʱ��
	public static void getTimeFromLine(String line)
	{
		String reg = "[0-9]{1,2}H  0M  -\\s{2,3}[0-9]{1,2}H  0M";
		Pattern p = Pattern.compile(reg);
		Matcher m = p.matcher(line);
		if (m.find())
		{
			String beginTime = m.group().substring(0, m.group().indexOf("H"));
			beginTimeInt = Integer.parseInt(beginTime);
			endTimeInt = beginTimeInt+1;
			System.out.println("�˴�ʱ��Ϊ"+beginTimeInt+"��"+endTimeInt);
		}
		else
			System.out.println("û�ҵ�ʱ�����");
	}
	
	//����
	public static void skipLine(int lineToSkip) throws IOException
	{
		for (int i = 0;i <lineToSkip;i++)
		{
			line = lnr.readLine();
		}
	}
	
	//��ȡ�������ı�����
	public static void getTrafficFromLine()throws IOException
	{
		traffic1 = line.trim().split(" +");
		for (String s : traffic1)
		{
			System.out.print(s+"**");
		
			
		}
		skipLine(1);
		traffic2 = line.trim().split(" +");
		for (String s1 : traffic2)
		{
			System.out.print(s1+"**");
			
		}
		storageToDatabase(trafficDate,beginTimeInt,endTimeInt,traffic1,traffic2);
		
	}
	
	//�洢�����ݿ�
	public static void storageToDatabase(String trafficDate,int beginTimeInt,int endTimeInt,String[] traffic1,String[] traffic2)
	{
		System.out.println("�˴λ���ͳ������Ϊ"+trafficDate+"ʱ��Ϊ"+beginTimeInt+"��"+endTimeInt+"ʱ,\r\nͳ�Ƶ�λΪ"+traffic1[0]);
	}
	
	
}
